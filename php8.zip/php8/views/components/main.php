<main>
    <h2>Comment Form</h2>
    <?php include 'form.php'; ?>
    <h2>Comments</h2>
    <?php include 'handlers/comments.php'; ?>
</main>
