<form action="../handlers/form-handler.php" method="POST">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name"><br>
    <label for="comment">Comment:</label>
    <textarea id="comment" name="comment"></textarea><br>
    <button type="submit">Submit</button>
</form>
